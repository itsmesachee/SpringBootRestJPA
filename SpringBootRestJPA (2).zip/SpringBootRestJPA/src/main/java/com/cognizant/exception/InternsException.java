package com.cognizant.exception;

public class InternsException extends RuntimeException{
	
	private String message;
	
	public InternsException(String message){
		
		this.message=message;
	}

	public String getMessage() {
		return message;
	}

	
	
	

}
