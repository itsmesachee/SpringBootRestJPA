package com.cognizant.dao;

import java.util.List;

import com.cognizant.entity.Interns;

public interface InternsDAO {
	
	List<Interns> getAllInterns();
	Interns getInternById(int internId);
	boolean storeInternData(Interns intern);
	boolean updateInternLevel(Interns intern);
}
