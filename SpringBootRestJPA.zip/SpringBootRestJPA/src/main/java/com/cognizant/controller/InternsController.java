package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.entity.Interns;
import com.cognizant.service.InternsService;

@RestController
@RequestMapping("/interns")
public class InternsController {
	@Autowired
	private InternsService internService;
	@GetMapping("/allinterns")
	public ResponseEntity<List<Interns>> retrieveAllInterns(){
		
		List<Interns> internsList=internService.retrieveInternsService();
		ResponseEntity<List<Interns>> response=new ResponseEntity<List<Interns>>(internsList,HttpStatus.OK);
		return response;
		
		
		
	}

}
