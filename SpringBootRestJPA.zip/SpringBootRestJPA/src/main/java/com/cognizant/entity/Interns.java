package com.cognizant.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="Interns")
/*
 * Business Entity represents database table Interns
 */
@NamedQueries(
		
		@NamedQuery(name="findAllInterns",query="from Interns I")
		
		
		)
public class Interns {
	@Id
	@Column(name="intern_id")
	private int internId;
	
	@Column(name="intern_first_name")
	private String internFirstName;
	
	@Column(name="intern_last_name")
	private String internLastName;
	
	@Column(name="intern_age")
	private int intern_age;

	public int getInternId() {
		return internId;
	}

	public void setInternId(int internId) {
		this.internId = internId;
	}

	public String getInternFirstName() {
		return internFirstName;
	}

	public void setInternFirstName(String internFirstName) {
		this.internFirstName = internFirstName;
	}

	public String getInternLastName() {
		return internLastName;
	}

	public void setInternLastName(String internLastName) {
		this.internLastName = internLastName;
	}

	public int getIntern_age() {
		return intern_age;
	}

	public void setIntern_age(int intern_age) {
		this.intern_age = intern_age;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((internFirstName == null) ? 0 : internFirstName.hashCode());
		result = prime * result + internId;
		result = prime * result
				+ ((internLastName == null) ? 0 : internLastName.hashCode());
		result = prime * result + intern_age;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Interns other = (Interns) obj;
		if (internFirstName == null) {
			if (other.internFirstName != null)
				return false;
		} else if (!internFirstName.equals(other.internFirstName))
			return false;
		if (internId != other.internId)
			return false;
		if (internLastName == null) {
			if (other.internLastName != null)
				return false;
		} else if (!internLastName.equals(other.internLastName))
			return false;
		if (intern_age != other.intern_age)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Interns [internId=" + internId + ", internFirstName="
				+ internFirstName + ", internLastName=" + internLastName
				+ ", intern_age=" + intern_age + "]";
	}

	

	

}
