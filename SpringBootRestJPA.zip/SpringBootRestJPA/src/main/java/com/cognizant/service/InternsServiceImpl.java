package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.InternsDAO;
import com.cognizant.entity.Interns;
import com.cognizant.exception.InternsException;

@Service
public class InternsServiceImpl implements InternsService {
	@Autowired
	private InternsDAO internsDAO;

	public List<Interns> retrieveInternsService() {
		// TODO Auto-generated method stub
		List<Interns> interns= internsDAO.getAllInterns();
		if(interns.isEmpty()){
			throw new InternsException("No interns records found");
		}else{
			
			return interns;
		}
	}
	

}
