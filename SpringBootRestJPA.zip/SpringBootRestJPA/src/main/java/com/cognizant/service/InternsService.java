package com.cognizant.service;

import java.util.List;

import com.cognizant.entity.Interns;

public interface InternsService {
	List<Interns> retrieveInternsService();


}
