package com.cognizant.dao;

import java.util.List;

import com.cognizant.entity.Interns;

public interface InternsDAO {
	
	List<Interns> getAllInterns();

}
