package com.cognizant.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cognizant.entity.Interns;
@Repository
public class InternsDAOImpl implements InternsDAO {
	
	@PersistenceContext
	private EntityManager manager;
	

	public List<Interns> getAllInterns() {
		// TODO Auto-generated method stub
		Query query=manager.createNamedQuery("findAllInterns");
		List<Interns> interns=query.getResultList();
		return interns;
	}

}
